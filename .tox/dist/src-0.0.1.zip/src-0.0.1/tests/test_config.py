def test_generic() :
    a = 30
    b =30
    assert a == b